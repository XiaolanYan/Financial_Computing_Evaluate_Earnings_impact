﻿//
//  main.cpp
//  Licurl
//
//  Created by Katherine Zeng on 11/21/21.
//
#pragma once

#include "menus.h"
using namespace std;

int main() {

    Menu();
    return 0;

}

