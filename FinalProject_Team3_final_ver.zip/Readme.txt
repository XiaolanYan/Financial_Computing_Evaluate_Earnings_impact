This submission version is based on a windows terminal.

To successfully run this program, please:
1) set the property configurations for libcurl
2) change the gnuplot exe location to your own location in the Config.h
